//Shreya Shukla
//CS211: Computer Architecture
//Monday, Nov 27, 2023
//Homework 2

// Created by AJ DiLeo
// For use in CS211 Fall 2023 ONLY

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <limits.h>

#define MAX_BIT_POSITION 32

/*
// Cache for storing FizzBuzz results for each bit position
char cache[MAX_BIT_POSITION][3];

//working with 32-bit signed integers
// Initialize the cache with FizzBuzz results
void preComputeResults() {
    // TODO: For every possible position, pre-compute its corresponding string output
	// Make sure to handle the case where you will not replace the bit with Z, R, or U
	// Your advancedBitwiseFizzBuzz() code should know when to use the replacement and when to use the bit
    // Use 'Z' for numbers divisible by 3 and 5, 'R' for divisible by 3, and 'U' for divisible by 5
    for (int i = 0; i < MAX_BIT_POSITION; i++){
        if ((i%3 == 0) && (i%5 ==0)){
            strcpy (cache[i], 'Z'); //copies source to destination: 'Z' is copied to index i in cache
        }
        else if (i%3 == 0){
            strcpy (cache[i], 'R'); //copies source to destination: 'R' is copied to index i in cache
        }
        else if (i%5 == 0){
            strcpy (cache[i], 'U'); //copies source to destination: 'Z' is copied to index i in cache
        }
        //If none of the conditions are met, cache will remain uninitialized
    }
}

// Retrieve the FizzBuzz result for a specific bit position
char* getFizzBuzzForBit(int position) {
    // TODO: Return the FizzBuzz result for the given position from the cache
    return cache[position];
}

// Perform the advanced Bitwise FizzBuzz logic on the given number
void advancedBitwiseFizzBuzz(int32_t N) {
    // TODO: Implement the advanced Bitwise FizzBuzz logic
    // - For each bit in the number, apply the FizzBuzz logic
    // - Replace the MSb with 'S' if it's set
    // - Print each bit or its FizzBuzz result
    // - Format the output with a space every four bits

	// Each bitstring should be outputted from Left -> Right, MSb -> LSb
	// Index 0 of the bitstring should be the LSb
	// E.g., 
	// 1  0  0 1 0 0 0 1 1 1 0 0   <=== bitstring
	// 11 10 9 8 7 6 5 4 3 2 1 0   <=== indices

    //replace MSB with 'S' for the most significant bit
    int MSB = N >> 1; //get the MSB using the right-shift operator
    if (MSB == 1){
        strcpy(cache[MAX_BIT_POSITION-1], 'S');
    }
    for (int i = MAX_BIT_POSITION -2; i>=0; i--){
        int bit = N >> 1;
        char* fizzBuzz = getFizzBuzzForBit(i);
        // Print a space every four bits
        if ((i % 4) == 0) {
            printf(" ");
        }
        //print fizzBuzz results if bit is 1
        if ((bit == 1)&& (strlen(fizzBuzz)!= 0)){
            printf ('%c', fizzBuzz);
        }
        else{
            printf ('%d', bit);
        }
    }
}
*/
//program: cmd line -> string -> one's complement -> two's complement -> function calls (precompute & advanced)
// Main function to run the program
int main(int argc, char *argv[]) {
    // TODO: Parse the command line argument to get the input number
    char* input = strdup (argv[1]);
    
    // Use strtol to convert the string to a long integer
    long num = strtol(input,NULL,10);
    
    //printf ("%ld\n", num); //test the value of num

    // Check if the number is within the range of a 32-bit signed integer
	// If so, print "Number out of range for a 32-bit integer\n"
    
    //the number should be between -(2^31) and (2^31)-1, inclusive, aka -2147483648 and 2147483647
    int min = -2147483648;
    int max = 2147483647;

    //exit function if num is not within range
    if (!( (num>= min) && (num<= max) )){
        printf("Number out of range for a 32-bit integer\n");
        exit(0);
    }

    //steps below convert long num to binary bit string
    long temp = num;
    int numBits = 32;
    char bitString[numBits]; //char bitString[numBits +1] //plus 1 to store null-terminating

    //algorithm to go from decimal to binary
    //divide decimal by 2, take remainder as bits going left to right, lsb to msb
    //starting with index 31 ---> index 0
    for (int i = numBits - 1; i >= 0; i--){
        //bitString[i] = temp % 2 + '0';
        bitString[i] = (temp & 1) + '0';
        //bit-masking (temp & 1) alllows us to get the lsb of temp
        //it's the same as doing temp % 2   //adding '0' will convert the int to a char
        temp = temp >> 1; //right shift operator divides by 2^1
    }
    bitString[numBits] = '\0'; //null-terminating string at index 32
    //printf ("%s\n", bitString);

    //convert binary to one's complement
    char onescomp[numBits];
    
    for (int j = 0; j < numBits; j++) {
        printf("Step %d\n", j);
        printf("(bitString[j]: %c\n", (bitString[j]));
        printf("bitString[%d] == '0'? %s\n", j,(bitString[j])=='0'?"true":"false");
        onescomp[j] = ((bitString[j] == '0') ? '1' : '0'); //if the bit is 0, then '1'; otherwise '0'
        printf ("Binary:%s\n", bitString);
        printf ("1s Cmp:%s\n\n", onescomp);
        //printf("onescomp[%d]: %c\n", j, onescomp[j]);
        //printf("bitString[%d]: %c, onescomp[%d]: %c\n", j, bitString[j], j, onescomp[j]);
    }
    //printf ("Length of onescomp: %lu\n", strlen(onescomp));
    //printf ("%s\n", onescomp
    
    //convert to two's complement
    /*
    char twoscomp[numBits];
    int carry = '0';
    for (int i = 0; i < numBits; i++){
        int sum = (onescomp[i] - '0 + '1' - '0' + carry - '0'); 
        //sum can be 0, 1, 2, or 3
        if (sum == 3){
            twoscomp[i] = '1';
            carry = '1';
        }
        else if (sum == 2){
            twoscomp[i] = '0';
            carry = '1';
        }
        else if (sum == 1){
            twoscomp[i] = '1';
            carry = '0';
        }
        else if (sum == 0){
            twoscomp[i] = '0';
            carry = '0';
        }
    } */
    // TODO: Initialize the cache
    //preComputeResults();
    // TODO: Call advancedBitwiseFizzBuzz with the parsed number
	// Make sure the number is an int32_t
    //advancedBitwiseFizzBuzz((int32_t)num); //typecasting to type int32_t
    return 0;
}

